# Foundation Storage Cleanup Advisor

Created: 2026-05-05T13:18:49

Total outputs MB: **122.482**

## Recommendations

- No cleanup needed now. Output size is under 500 MB.

## Largest Output Folders

| Folder | MB | Files |
|---|---:|---:|
| `outputs/foundation_eval` | 67.924 | 646 |
| `outputs/foundation_handoff_bundle` | 12.62 | 341 |
| `outputs/foundation_quarantine` | 9.428 | 50 |
| `outputs/foundation_major_suite` | 4.435 | 67 |
| `outputs/foundation_saved` | 4.108 | 12 |
| `outputs/foundation_predictive_coding` | 3.93 | 47 |
| `outputs/foundation_one_button_ops` | 3.731 | 406 |
| `outputs/brain_zoo` | 2.965 | 16 |
| `outputs/foundation_snapshot` | 2.589 | 76 |
| `outputs/foundation_decision_pipeline` | 2.085 | 57 |
| `outputs/foundation_autoloop` | 2.046 | 260 |
| `outputs/foundation_headless_training` | 0.893 | 410 |
| `outputs/foundation_auto_orchestrator` | 0.89 | 317 |
| `outputs/foundation_memory_graph` | 0.623 | 2 |
| `outputs/foundation_memory_recall` | 0.597 | 59 |
| `outputs/foundation_answer_console` | 0.573 | 60 |
| `outputs/foundation_verifier` | 0.317 | 67 |
| `outputs/20260429_025235_kntPDI` | 0.284 | 3 |
| `outputs/foundation_brain_council` | 0.276 | 69 |
| `outputs/foundation_task_journal` | 0.259 | 2 |
| `outputs/models` | 0.242 | 3 |
| `outputs/foundation_action_queue` | 0.227 | 2 |
| `outputs/foundation_processor` | 0.221 | 3 |
| `outputs/foundation_exports` | 0.207 | 18 |
| `outputs/foundation_router` | 0.171 | 73 |
| `outputs/foundation_cleanup` | 0.145 | 1 |
| `outputs/foundation_utility_intelligence` | 0.117 | 49 |
| `outputs/foundation_answer_benchmark_runner` | 0.109 | 11 |
| `outputs/battery_followup` | 0.091 | 7 |
| `outputs/expanded_pipeline` | 0.075 | 6 |