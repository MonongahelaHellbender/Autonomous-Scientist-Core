# Foundation Automation Manifest

Created: 2026-05-05T13:18:49

## Policy

- auto_source_edits_allowed: **False**
- auto_delete_allowed: **False**
- auto_package_install_allowed: **False**
- auto_long_training_allowed: **False**
- human_approval_required_for_source_edits: **True**

## Commands

### one_button_master

```bash
scientist-env/bin/python -m tools.foundation_one_button_ops --master --benchmark-limit 3
```
- Risk: low
- Edits source: False

### quick_orchestrator

```bash
scientist-env/bin/python -m tools.foundation_auto_orchestrator --quick
```
- Risk: low
- Edits source: False

### benchmark_orchestrator

```bash
scientist-env/bin/python -m tools.foundation_auto_orchestrator --benchmark --limit 3
```
- Risk: low-medium
- Edits source: False

### safety_gate

```bash
scientist-env/bin/python -m tools.foundation_safety_gate --save
```
- Risk: low
- Edits source: False

### predictive_coding

```bash
scientist-env/bin/python -m tools.foundation_predictive_coding --save
```
- Risk: low
- Edits source: False
